#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>
#include "cJSON.h"
#include "cJSON.c"
#include <stdbool.h>
#include <string.h>
#define MAX 80
#define PORT 12345
#define SA struct sockaddr
char Token[200];

int mksocket()
{
    int client_socket, server_socket;
    struct sockaddr_in servaddr, cli;

    WORD wVersionRequested;
    WSADATA wsaData;
    int err;

    // Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0)
    {
        // Tell the user that we could not find a usable Winsock DLL.
        printf("WSAStartup failed with error: %d\n", err);
        return 1;
    }

    // Create and verify socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket == -1)
    {
        printf("Socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");

    // Assign IP and port
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    // Connect the client socket to server socket
    if (connect(client_socket, (SA*)&servaddr, sizeof(servaddr)) != 0)
    {
        printf("Connection to the server failed...\n");
        exit(0);
    }
    else
        printf("Successfully connected to the server..\n");
    return client_socket;

}

void Idetifying()
{
    printf(" Account Menu:\n 1: Register  \n 2: Login\n");
    int command;
    scanf("%d",&command);
    if(command == 1)
    {
        Register();
    }
    else if(command == 2)
    {
        Login();
    }
    else
    {
        printf("Unavailable key! try again.\n");
        Idetifying();
    }
}


void Register()
{
    char username[200],password[200],regist[400];
    printf("Enter Username\n");
    scanf("%s",username);
    printf("Enter Password\n");
    scanf("%s",password);
    sprintf(regist,"register %s, %s\n",username,password);
    int client_socket = mksocket();
    send(client_socket, regist, sizeof(regist), 0);
    memset(regist, 0, sizeof(regist));
    recv(client_socket, regist, sizeof(regist), 0);
    cJSON *json = cJSON_Parse(regist);
    cJSON *type = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (strcmp(type->valuestring, "Error")!= 0)
    {
        printf("You are successfully registered!now you can log in :\n");
        Login();
    }
    else
    {
        printf("%s\n", cJSON_GetObjectItemCaseSensitive(json, "content")->valuestring);
        main();
    }
}


void Login()
{
    char username[200],password[200],log[400];
    printf("Enter Username\n");
    scanf("%s",username);
    printf("Enter Password\n");
    scanf("%s",password);
    sprintf(log,"login %s, %s\n",username,password);
    int client_socket = mksocket();
    send(client_socket, log, sizeof(log), 0);
    memset(log, 0, sizeof(log));
    recv(client_socket, log, sizeof(log), 0);
    cJSON *json = cJSON_Parse(log);
    cJSON *type = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (strcmp(type->valuestring, "Error")!= 0)
    {
        strcpy(Token,cJSON_GetObjectItemCaseSensitive(json, "content")->valuestring);
        Begin();
    }
    else
    {
        printf("%s\n", cJSON_GetObjectItemCaseSensitive(json, "content")->valuestring);
        Idetifying();
    }
}


void Begin()
{
    printf(" 1: Create Channel\n 2: Join Channel\n 3: Logout\n");
    int num;
    scanf("%d",&num);
    switch(num)
    {
    case 1:
        Create_channel();
        break;
    case 2:
        Join_channel();
        break;
    case 3:
        Logout();
        break;
    default:
        Begin();
    }
}

void Create_channel()
{
    char channelname[500],endofcreatingchannel[5000];
    printf("Please enter new channel's name:\n");
    scanf("%s",channelname);
    sprintf(endofcreatingchannel,"create channel %s, %s\n",channelname,Token);
    int channel_soket = mksocket();
    send(channel_soket,endofcreatingchannel,sizeof(endofcreatingchannel),0);
    recv(channel_soket,endofcreatingchannel,sizeof(endofcreatingchannel),0);
    cJSON *json = cJSON_Parse(endofcreatingchannel);
    cJSON *type = cJSON_GetObjectItemCaseSensitive(json,"type");
    if(strcmp(type ->valuestring,"Error")==0)
    {
        printf("channel name is used before!please try again!\n");
        Begin();
    }
    Menu();

}

void Join_channel()
{
    char channelname[500],endofjoiningchannel[5000];
    printf("Please enter channel's name:\n");
    scanf("%s",channelname);
    sprintf(endofjoiningchannel,"join channel %s, %s\n",channelname,Token);
    int channel_soket = mksocket();
    send(channel_soket,endofjoiningchannel,sizeof(endofjoiningchannel),0);
    recv(channel_soket,endofjoiningchannel,sizeof(endofjoiningchannel),0);
    cJSON *json = cJSON_Parse(endofjoiningchannel);
    cJSON *type = cJSON_GetObjectItemCaseSensitive(json,"type");
    cJSON *content = cJSON_GetObjectItemCaseSensitive(json,"content");
    if(strcmp(type ->valuestring,"Error")==0)
    {
        printf("%s",content->valuestring);
        Begin();
    }
    printf("you joined the channel!\n");
    Menu();
}

void Logout()
{
    char logoutstr[1000];
    sprintf(logoutstr,"logout %s\n",Token);
    int logout_soket = mksocket();
    send(logout_soket,logoutstr,sizeof(logoutstr),0);
    printf("You are successfully logged out!\n");
    Idetifying();
}

void Menu()
{
    printf(" 1: Send Massage\n 2: Refresh\n 3: Channel Members \n 4: Leave Channel\n");
    int num;
    scanf("%d",&num);
    switch(num)
    {
    case 1:
        Send_massage();
        break;
    case 2:
        Refresh();
        break;
    case 3:
        Channel_mambers();
        break;
    case 4:
        Leave_channel();
        break;
    default:
        Menu();
    }
}

void Send_massage()
{
    char message[10000],sendmessage[10000]="send ";
    printf("Please write your message:\n");
    scanf("\n%[^\n]",message);
    strcat(sendmessage, message);
    strcat(sendmessage,", ");
    strcat(sendmessage, Token);
    strcat(sendmessage, "\n");
    int client_socket = mksocket();
    send(client_socket, sendmessage, sizeof(sendmessage), 0);
    Menu();
}

void Refresh()
{
    char refreshall[10000];
    sprintf(refreshall,"refresh %s\n",Token);
    int refresh_soket = mksocket();
    send(refresh_soket,refreshall,sizeof(refreshall),0);
    memset(refreshall,0,sizeof(refreshall));
    recv(refresh_soket,refreshall,sizeof(refreshall),0);
    cJSON *json = cJSON_Parse(refreshall);
    cJSON *content = cJSON_GetObjectItemCaseSensitive(json,"content");
    cJSON *communication = NULL ;
    printf("Here are all new messages:\n");
    cJSON_ArrayForEach(communication,content)
    {
        cJSON *sender = cJSON_GetObjectItemCaseSensitive(communication,"sender");
        cJSON *content2 = cJSON_GetObjectItemCaseSensitive(communication,"content");
        if(strcmp(sender -> valuestring,"server")!= 0)
        {
            printf("%s said : ",sender->valuestring);
            printf("%s\n",content2->valuestring);
        }
    }
    Menu();

}

void Channel_mambers()
{
    int num = 0;
    char members[1000];
    sprintf(members,"channel members %s\n",Token);
    int member_soket = mksocket();
    send(member_soket,members,sizeof(members),0);
    memset(members, 0, sizeof(members));
    recv(member_soket,members,sizeof(members),0);
    cJSON *parse = cJSON_Parse(members);
    cJSON *content = cJSON_GetObjectItemCaseSensitive(parse, "content");
    cJSON *communication = NULL;
    char *membertable[500];
    for(int i = 0; i < 500; i++)
    {
        membertable[i]= malloc(500*sizeof(char));
    }
    cJSON_ArrayForEach(communication,content)
    {
        strcpy(membertable[num],communication -> valuestring);
        printf("member number %d is : %s\n",num+1,membertable[num]);
        num++;
    }
    Menu();
}

void Leave_channel()
{
    char leave[1000];
    sprintf(leave,"leave %s\n",Token);
    int leave_soket = mksocket();
    send(leave_soket,leave,sizeof(leave),0);
    memset(leave,0,sizeof(leave));
    recv(leave_soket,leave,sizeof(leave),0);
    cJSON *json = cJSON_Parse(leave);
    cJSON *type = cJSON_GetObjectItemCaseSensitive(json, "type");
    if (strcmp(type->valuestring, "Error")!= 0)
    {
        printf("You left the current channel!\n");
        Begin();
    }
}




int main()
{
    //first step: identifying
    Idetifying();
    //second step: Begin
    Begin();
}
