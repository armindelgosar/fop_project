#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <winsock2.h>
#include "cJSON.h"
#include "cJSON.c"
#define MAX 80
#define PORT 12345
#define SA struct sockaddr

int server_socket, client_socket;
struct sockaddr_in server, client;

char buffer[MAX];
char result[1000];

struct users
{
    char username[100];
    char token[20];
    int existinchannel;//it should be 0 or 1
    char channelname[100];
};
struct channelname
{
    char name[100];
};
struct users users[1000];
struct channelname channels[1000];
int usercounter,channelcounter;
char userrightnow[100];

int confirmuser(char *testtoken)
{
    for(int i = 0 ; i < usercounter; i++)
    {
        if(strcmp(testtoken,users[i].token)==0)
        {
            strcpy(userrightnow,users[i].username);
            return 1;
        }
    }
    return 0;
}

void tokenmaking(char *token, int size)
{
    const char charset[] = "abcdefghijklmnopuvwxyzABCDEFGHIJKLMNOP...";
    if(size)
    {
        --size;
        for(size_t n = 0; n < size ; n++)
        {
            int key = rand() % (int)(sizeof charset - 1);
            token[n] = charset[key];
        }
        token[size] = '\0';
    }
}

void login()
{
    char username[100],password[100],garbage[100],garbageusername[100];//garbage is used to remove name of command
    sscanf(buffer,"%s %s %s",garbage,garbageusername,password);
    garbageusername[strlen(garbageusername)-1]='\0';
    strcpy(username,garbageusername);
    char filename[100]="";
    sprintf(filename,"users\\%s.txt",username);
    FILE *fptr = fopen(filename,"r");
    if(fptr != NULL)
    {
        char data[1000];
        int charindata = 0;
        while(1)
        {
            char c = fgetc(fptr);
            if(c != EOF)
            {
                data[charindata] = c;
                charindata++;
            }
            else
                break;
        }
        cJSON *json = cJSON_Parse(data);
        cJSON *type = cJSON_GetObjectItemCaseSensitive(json, "password");
        if(strcmp(type -> valuestring,password) == 0)
        {
            tokenmaking(users[usercounter].token,20);
            sprintf(result,"{\"type\":\"AuthToken\",\"content\":\"%s\"}",users[usercounter].token);
            strcpy(users[usercounter].username,username);
            usercounter++;
        }
        else
        {
            strcpy(result,"{\"type\":\"Error\",\"content\":\"wrong password ...\"}");
        }
        fclose(fptr);
    }
    else if(fptr == NULL)
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"Username is not valid.\"}");
        fclose(fptr);
    }
    send(client_socket, result, sizeof(result), 0);
    return;
}
void registerr()
{
    char username[100],password[100],garbage[100],garbageusername[100];//garbage is used to remove name of command
    sscanf(buffer,"%s %s %s",garbage,garbageusername,password);
    garbageusername[strlen(garbageusername)-1]='\0';
    strcpy(username,garbageusername);
    char filename[100]="";
    sprintf(filename,"users\\%s.txt",username);
    FILE *test = fopen(filename,"r");
    if(test == NULL)
    {
        fclose(test);
        FILE *fptr = fopen(filename,"w");
        fprintf(fptr,"{\"username\":\"%s\",\"password\":\"%s\"}",username,password);
        fclose(fptr);
        strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
    }
    else
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"this username is not available.\"}");
        fclose(test);
    }
    send(client_socket, result, sizeof(result), 0);
    return;
}
void logout()
{
    char checktoken[20],garbage[100];
    sscanf(buffer,"%s %s",garbage,checktoken);
    for(int i = 0; i < usercounter; i++)
    {
        if(strcmp(checktoken,users[i].token)==0)
        {
            users[i].token[0]='\0';
        }
    }
    strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
}
void create_channel()
{
    char garbage1[100],garbage2[100],garbagechannelname[100],channelname[100],testtoken[20];
    sscanf(buffer,"%s %s %s %s",garbage1,garbage2,garbagechannelname,testtoken);
    if(confirmuser(testtoken)== 0)
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"unknown token.\"}");
    }
    else
    {
        garbagechannelname[strlen(garbagechannelname)-1]='\0';
        strcpy(channelname,garbagechannelname);
        char filename[100]="";
        sprintf(filename,"channels\\%s.txt",channelname);
        FILE *fptr = fopen(filename,"r");
        if(fptr != NULL)
        {
            strcpy(result,"{\"type\":\"Error\",\"content\":\"there is another channel with this name!\"}");
            fclose(fptr);
        }
        else
        {
            FILE *ffptr = fopen(filename,"w");
            fprintf(ffptr,"{\"messages\":[{\"sender\":\"server\",\"content\":\"%s created %s.\"}],\"name\":\"%s\"}",userrightnow,channelname,channelname);
            fclose(ffptr);
            for(int i = 0;i < usercounter;i++)//this part is used to show that user is in a channel
            {
                if(strcmp(users[i].token,testtoken)== 0)
                {
                    users[i].existinchannel = 1;
                    strcpy(users[i].channelname,channelname);
                }
            }
            strcpy(channels[channelcounter].name,channelname);
            strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
        }
    }
    send(client_socket, result, sizeof(result), 0);
    return;
}

void leave_channel()
{
    char garbage1[100],testtoken[20];
    sscanf(buffer,"%s %s",garbage1,testtoken);
    if(confirmuser(testtoken)== 0)
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"unknown token.\"}");
    }
    for(int i = 0; i < usercounter;i++)//check if the user exists in a channel or not
    {
        if(strcmp(users[i].token,testtoken) == 0)
        {
            if(users[i].existinchannel == 1)
            {
                users[i].existinchannel = 0;
                users[i].channelname[0] = '\0';
                 strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
                 send(client_socket, result, sizeof(result), 0);
                 return;
            }
            else
            {
                strcpy(result,"{\"type\":\"Error\",\"content\":\"not joined any channel\"}");
            }
        }
    }

}
void join_channel()
{
    char garbage1[100],garbage2[100],garbagechannelname[100],channelname[100],testtoken[20];
    sscanf(buffer,"%s %s %s %s",garbage1,garbage2,garbagechannelname,testtoken);
    if(confirmuser(testtoken)== 0)
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"unknown token.\"}");
    }
    else
    {
         garbagechannelname[strlen(garbagechannelname)-1]='\0';
         strcpy(channelname,garbagechannelname);
    }
    char filename[1000];
    sprintf(filename,"channels\\%s.txt",channelname);
    FILE *fptr = fopen(filename,"r");
    if(fptr == NULL)
    {
        strcpy(result,"{\"type\":\"Error\",\"content\":\"channel doesn't exist!\"}");
        send(client_socket, result, sizeof(result), 0);
        fclose(fptr);
        return;
    }
    for(int i = 0; i < usercounter;i++)//check if the user exists in a channel or not
    {
        if(strcmp(users[i].token,testtoken) == 0)
        {
            if(users[i].existinchannel == 1)
            {
                 strcpy(result,"{\"type\":\"Error\",\"content\":\"user is in another channel!\"}");
                 send(client_socket, result, sizeof(result), 0);
                 return;
            }
        }
    }
    for(int i = 0; i < usercounter;i++)//check if the user exists in a channel or not
    {
        if(strcmp(users[i].token,testtoken) == 0)
        {
          strcpy(users[i].channelname,channelname);
          users[i].existinchannel = 1;
          strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
            send(client_socket, result, sizeof(result), 0);
           return;
        }
    }

}
void refresh()
{
    char garbage[10],testtoken[20];
    sscanf(buffer,"%s %s",garbage,testtoken);
    for(int i = 0; i < usercounter;i++)
    {
        if(strcmp(users[i].token,testtoken)==0)
        {
            if(users[i].existinchannel == 1)
            {
                char filename[100]="";
                sprintf(filename,"channels\\%s.txt",users[i].channelname);
                FILE *fptr = fopen(filename,"r");
                char data[1000];
                int charindata = 0;
                while(1)
                {
                    char c = fgetc(fptr);
                    if(c != EOF)
                    {
                    data[charindata] = c;
                    charindata++;
                    }
                    else
                    break;
                }
                fclose(fptr);
                cJSON *root = cJSON_Parse(data);
                cJSON *Messages_Array = cJSON_GetObjectItem(root,"Messages");
                cJSON *sendroot = cJSON_CreateObject();
                cJSON_AddItemToObject(root,"type",cJSON_CreateString("List"));
                cJSON_AddItemToObject(sendroot,"content",Messages_Array);
                char *out = cJSON_PrintUnformatted(sendroot);
                strcpy(result,out);
                send(client_socket, result, sizeof(result), 0);
                cJSON_Delete(root);
                cJSON_Delete(sendroot);
                return;
            }
            else
            {
              strcpy(result,"{\"type\":\"Error\",\"content\":\"user not found in any channel!\"}");
              send(client_socket, result, sizeof(result), 0);
              return;
            }
        }
    }
        strcpy(result,"{\"type\":\"Error\",\"content\":\"wrong token!\"}");
        send(client_socket, result, sizeof(result), 0);
        return;
}
void send_message()
{
    int j = 0;
    char finalmessage[1000],message[1000],testtoken[20];
    buffer[strlen(buffer)-1]='\0';
    for(int i = strlen(buffer) - 19, j = 0; i < strlen(buffer);i++,j++)
    {
        testtoken[j]= buffer[i];
    }
    testtoken[20]='\0';
    for(int i = 5; i < strlen(buffer) - 21;i++,j++)
    {
        message[j]= buffer[i];
    }
    message[j]='\0';
    for(int i = 0;i < usercounter;i++)
    {
        if(strcmp(users[i].token,testtoken)==0)
        {
            if(users[i].existinchannel == 1)
            {

                char filename[100]="";
                sprintf(filename,"channels\\%s.txt",users[i].channelname);
                sprintf(finalmessage,"{\"sender\":\"%s\",\"content\":\"%s\"}",users[i].username,message);
                FILE *fptr = fopen(filename,"r");
                char data[1000];
                int charindata = 0;
                while(1)
                {
                    char c = fgetc(fptr);
                    if(c != EOF)
                    {
                    data[charindata] = c;
                    charindata++;
                    }
                    else
                    break;
                }
            fclose(fptr);
            cJSON *dataa = cJSON_Parse(data);
            cJSON *finaldata = cJSON_Parse(finalmessage);
            cJSON *messagee = cJSON_GetObjectItem(dataa,"messages");
            cJSON_AddItemToArray(messagee,finaldata);
            FILE *ffptr = fopen(filename,"w");
            char *out = cJSON_PrintUnformatted(dataa);
            fprintf(ffptr,"%s",out);
            fclose(ffptr);
            strcpy(result,"{\"type\":\"Successful\",\"content\":\"\"}");
            send(client_socket, result, sizeof(result), 0);
            return;
            }
            else
            {
              strcpy(result,"{\"type\":\"Error\",\"content\":\"user not found in any channel!\"}");
              send(client_socket, result, sizeof(result), 0);
              return;
            }
        }
    }
        strcpy(result,"{\"type\":\"Error\",\"content\":\"wrong token!\"}");
        send(client_socket, result, sizeof(result), 0);
        return;
}



void channel_members()
{
    char garbage1[10],garbage2[10],testtoken[20];
    sscanf(buffer,"%s %s %s",garbage1,garbage2,testtoken);
     cJSON *root = cJSON_CreateObject();
    cJSON *content = cJSON_AddArrayToObject(root,"content");
    char channelname[100]= "";
    for(int i = 0; i < usercounter;i++)
    {
        if(strcmp(users[i].token,testtoken)==0)
        {
            strcpy(channelname,users[i].channelname);
            for(int i = 0;i < usercounter;i++)
            {
                if(strcmp(channelname,users[i].channelname)==0)
                {
                    cJSON_AddItemToArray(content,cJSON_CreateString(users[i].username));
                }
            }

            cJSON_AddItemToObject(root,"type",cJSON_CreateString("List"));
            char *out = cJSON_PrintUnformatted(root);
            strcpy(result,out);
            send(client_socket, result, sizeof(result), 0);
            cJSON_Delete(root);
            return;
        }
        else
            {
              strcpy(result,"{\"type\":\"Error\",\"content\":\"user not found in any channel!\"}");
              send(client_socket, result, sizeof(result), 0);
              return;
            }
    }
    strcpy(result,"{\"type\":\"Error\",\"content\":\"wrong token!\"}");
        send(client_socket, result, sizeof(result), 0);
        return;
}

void process()
{
    if(strncmp(buffer,"login",5) == 0)
    {
        login();
    }
    else if(strncmp(buffer,"register",8)== 0)
    {
        registerr();
    }
    else if(strncmp(buffer,"logout",6)== 0)
    {
        logout();
    }
    else if(strncmp(buffer,"create channel",14)== 0)
    {
        create_channel();
    }
    else if(strncmp(buffer,"join channel",12)==0)
    {
        join_channel();
    }
    else if(strncmp(buffer,"channel members",15) == 0)
    {
        channel_members();
    }
    else if(strncmp(buffer,"refresh",7) == 0)
    {
        refresh();
    }
    else if(strncmp(buffer,"leave",5)==0)
    {
        leave_channel();
    }
    else if(strncmp(buffer,"send",4)==0)
    {
        send_message();
    }
    else
    {
        printf("Not valid command ...\n");
        main();
    }
}

// Function designed for chat between client and server.
void chat()
{
    int n;
    while (true)
    {
        connecttoserver();
        memset(buffer, 0, sizeof(buffer));

        // Read the message from client and copy it to buffer
        recv(client_socket, buffer, sizeof(buffer), 0);

        // Print buffer which contains the client message
        process(buffer);
        // Send the buffer to client

        // If the message starts with "exit" then server exits and chat ends
        if (strncmp("exit", buffer, 4) == 0)
        {
            printf("Server stopping...\n");
            return;
        }
    }
}

// Driver function
int connecttoserver()
{

    WORD wVersionRequested;
    WSADATA wsaData;
    int err;

    // Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h
    wVersionRequested = MAKEWORD(2, 2);

    err = WSAStartup(wVersionRequested, &wsaData);
    if (err != 0)
    {
        // Tell the user that we could not find a usable Winsock DLL.
        printf("WSAStartup failed with error: %d\n", err);
        return 1;
    }

    // Create and verify socket
    server_socket = socket(AF_INET, SOCK_STREAM, 6);
    if (server_socket == INVALID_SOCKET)
        wprintf(L"socket function failed with error = %d\n", WSAGetLastError() );
    else
        printf("Socket successfully created..\n");

    // Assign IP and port
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = htonl(INADDR_ANY);
    server.sin_port = htons(PORT);

    // Bind newly created socket to given IP and verify
    if ((bind(server_socket, (SA *)&server, sizeof(server))) != 0)
    {
        printf("Socket binding failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully bound..\n");

    // Now server is ready to listen and verify
    if ((listen(server_socket, 5)) != 0)
    {
        printf("Listen failed...\n");
        exit(0);
    }
    else
        printf("Server listening..\n");

    // Accept the data packet from client and verify
    int len = sizeof(client);
    client_socket = accept(server_socket, (SA *)&client, &len);
    if (client_socket < 0)
    {
        printf("Server accceptance failed...\n");
        exit(0);
    }
    else
        printf("Server acccepted the client..\n");

    // Function for chatting between client and server


    // Close the socket
    closesocket(server_socket);
}

int main()
{
    chat();
    return 0;
}
